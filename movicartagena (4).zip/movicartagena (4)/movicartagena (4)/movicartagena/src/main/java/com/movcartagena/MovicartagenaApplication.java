package com.movcartagena;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovicartagenaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovicartagenaApplication.class, args);
	}

}
