package com.movcartagena.controller;

import com.movcartagena.model.Contacto;
import com.movcartagena.repository.ContactoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ContactoController {

    @Autowired
    private ContactoRepository contactoRepository;

    @PostMapping("/Contacto")
    public String enviarContacto(@RequestParam String nombre,
                                 @RequestParam String correo,
                                 @RequestParam String telefono,
                                 @RequestParam String mensaje) {
        // Crear una nueva instancia de Contacto y asignar los datos del formulario
        Contacto contacto = new Contacto();
        contacto.setNombre(nombre);
        contacto.setCorreo(correo);
        contacto.setTelefono(telefono);
        contacto.setMensaje(mensaje);

        // Guardar en la base de datos
        contactoRepository.save(contacto);

        // Redirigir al formulario con un parámetro de éxito
        return "redirect:/index.html";
    }
}
